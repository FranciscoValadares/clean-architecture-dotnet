export * from './footer.component';
