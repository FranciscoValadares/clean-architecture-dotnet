import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';

import { routes } from './app.routes';
import { CoreModule } from './core/core.module';
import { PreloadAllModules, RouterModule } from '@angular/router';

import { AppComponent } from './app/app.component';
import { MainContentComponent } from './shared/ui/main-content/main-content.component';
import { SidebarComponent } from './shared/ui/sidebar/sidebar.component';
import { FooterComponent } from './shared/ui/footer/footer.component';
import { HeaderComponent } from './shared/ui/header/header.component';
import { AuthModule } from './auth/auth.module';
// import { HeaderComponent } from './shared/ui/header';
// import { FooterComponent } from './shared/ui/footer';
// import { SidebarComponent } from './sidebar/sidebar.component';
// import { MainContentComponent } from './main-content/main-content.component';


@NgModule({
  // declarations: [AppComponent],
  imports: [
    // Angular
    BrowserModule,

    // Core
    CoreModule,

    // Submodules
    AuthModule,

    // Application
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    MainContentComponent,


    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled',
      preloadingStrategy: PreloadAllModules,
    }),
  ],
  providers: [provideAnimationsAsync()],
  bootstrap: [AppComponent],
})
export class AppModule {}
