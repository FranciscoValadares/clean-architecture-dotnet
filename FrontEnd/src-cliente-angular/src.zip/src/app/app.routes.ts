import { Routes } from '@angular/router';
import { authGuard } from './auth/guards/auth.guard';
// import { authGuard } from './auth';

// export const routes: Routes = [];

export const routes: Routes = [

  {
    path: '',
    redirectTo: 'app-root',
    pathMatch: 'full',
  },
  {
    path: 'app-root',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./app/app.component').then(m => m.AppComponent),
  },



  // {
  //   path: 'login',
  //   loadComponent: () => import('./auth/login').then(m => m.LoginComponent),
  // },

  // {
  //   path: 'about',
  //   loadComponent: () => import('./features/about').then(m => m.AboutComponent),
  // },
  // {
  //   path: 'secured-feat',
  //   canActivate: [authGuard],
  //   loadComponent: () =>
  //     import('./features/secured-feat').then(m => m.SecuredFeatComponent),
  // },

  { path: '**', redirectTo: 'app-root' },
];
