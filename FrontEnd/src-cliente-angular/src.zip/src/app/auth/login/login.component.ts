import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';

import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'login',
  standalone: true,
  imports: [
    ReactiveFormsModule,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {


  constructor(
    private route: ActivatedRoute,
    private router: Router  ) {}

  readonly loginForm = new FormGroup({
    usuario: new FormControl('', {
      validators: [Validators.required],
      nonNullable: true,
    }),
    senha: new FormControl('', {
      validators: [Validators.required],
      nonNullable: true,
    }),
  });



  submit() {
    // const { username, password } = this.loginForm.value;
    // this.authFacade.login(username as string, password as string);

    console.log("Testing submit form...");
    this.router.navigate(['app'], { relativeTo: this.route });

  }


}


