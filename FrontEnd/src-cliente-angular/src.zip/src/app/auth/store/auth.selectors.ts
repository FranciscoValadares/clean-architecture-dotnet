import { createFeatureSelector, createSelector } from '@ngrx/store';

import { AuthState } from './auth.models';
import { AUTH_FEATURE_KEY } from './auth.reducer';

export const selectAuth = createFeatureSelector<AuthState>(AUTH_FEATURE_KEY);

export const selectIsLoggedIn = createSelector(selectAuth, (state: { isLoggedIn: any; }) => state.isLoggedIn);

export const selectLoginError = createSelector(selectAuth, (state: { hasLoginError: any; }) => state.hasLoginError);

export const selectIsLoadingLogin = createSelector(
  selectAuth,
  (  state: { isLoadingLogin: any; }) => state.isLoadingLogin
);

export const selectAuthUser = createSelector(selectAuth, (state: { user: any; }) => state.user);
